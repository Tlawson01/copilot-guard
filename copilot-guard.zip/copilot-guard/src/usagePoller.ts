import axios from "axios";

export async function fetchUsage(token: string) {
  const res = await axios.get("https://api.github.com/settings/billing/usage", {
    headers: { Authorization: `token ${token}` },
  });
  return res.data; // { includedMonthlyQty, usedMonthlyQty, cost }
}
