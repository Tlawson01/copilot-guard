import { fetchUsage } from "./usagePoller";
import notifier from "node-notifier";
import { IncomingWebhook } from "@slack/webhook";
// The module 'vscode' contains the VS Code extensibility API
// Import the module and reference it with the alias vscode in your code below
import * as vscode from "vscode";

// This method is called when your extension is activated
// Your extension is activated the very first time the command is executed
export function activate(context: vscode.ExtensionContext) {
	// ─── status-bar item ──────────────────────────────────────────────
	const status = vscode.window.createStatusBarItem(
		vscode.StatusBarAlignment.Left,
	);
	status.text = "Copilot 0 / 300";
	status.show();
	context.subscriptions.push(status);

	// ─── helpers ──────────────────────────────────────────────────────
	const cfg = () => vscode.workspace.getConfiguration();
	const token = () => cfg().get<string>("copilotGuard.token");
	const hookURL = () => cfg().get<string>("copilotGuard.webhook");
	const slack = hookURL() ? new IncomingWebhook(hookURL()!) : null;

	let warned50 = false,
		warned75 = false,
		warned90 = false;

	async function update() {
		if (!token()) return; // quit if PAT not set

		const u = await fetchUsage(token()!); // {usedMonthlyQty,…}
		const pct = u.usedMonthlyQty / u.includedMonthlyQty;

		status.text = `Copilot ${u.usedMonthlyQty}/${u.includedMonthlyQty}`;
		status.color = pct >= 0.9 ? "red" : undefined;

		const alert = (lvl: number) => {
			const msg = `⚠️ Copilot at ${lvl}% (${u.usedMonthlyQty}/${u.includedMonthlyQty})`;
			notifier.notify({ title: "Copilot Guard", message: msg });
			if (slack) slack.send(msg);
		};

		if (pct >= 0.9 && !warned90) {
			alert(90);
			warned90 = true;
		} else if (pct >= 0.75 && !warned75) {
			alert(75);
			warned75 = true;
		} else if (pct >= 0.5 && !warned50) {
			alert(50);
			warned50 = true;
		}
	}

	update(); // run once at load
	setInterval(update, 3 * 60_000);
}
