declare module "node-notifier";
